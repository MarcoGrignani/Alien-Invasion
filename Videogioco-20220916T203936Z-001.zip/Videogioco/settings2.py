
class Settings():
	"""a class to store all settings for alien invasions"""
	
	def __init__(self):
		"""inizialize the game's static settings"""
		#screen settings
		self.screen_width = 1600
		self.screen_heigth = 800
		self.bg_color = (230, 230, 230)
		
		self.ship_speed_factor = 1.5
