import sys
import pygame
from settings1 import Settings
from ship1 import Ship
import game_functions1 as gf

def run_game():
	pygame.init()
	ai_settings = Settings()
	screen = pygame.display.set_mode(
	(ai_settings.screen_width, ai_settings.screen_heigth))
	pygame.display.set_caption("Alien Invasion")
	
#the screen objects is called a surface. a surface is Pygame is a part
#of the screen where you display s game element. each element in the 
#game. like the aliens or the ship, is a surface

	ship = Ship(screen)

	while True:
		gf.check_events()
		gf.update_screen(ai_settings, screen, ship)
		
#main
run_game()
