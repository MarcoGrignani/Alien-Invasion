import sys
import pygame
from settings4 import Settings
from ship5 import Ship
import game_functions10 as gf
from pygame.sprite import Group

def run_game():
	pygame.init()
	ai_settings = Settings()
	screen = pygame.display.set_mode(
		(ai_settings.screen_width, ai_settings.screen_heigth))
	pygame.display.set_caption("Alien Invasion")
	
#the screen objects is called a surface. a surface is Pygame is a part
#of the screen where you display s game element. each element in the 
#game. like the aliens or the ship, is a surface

	ship = Ship(ai_settings, screen)
	bullets = Group()
	aliens = Group()
	
	gf.create_fleet(ai_settings, screen, aliens)

	while True:
		gf.check_events(ai_settings, screen, ship, bullets)
		ship.update()
		gf.update_bullets(bullets)
		gf.update_screen(ai_settings, screen, ship, aliens, bullets)
		
		
#main
run_game()
