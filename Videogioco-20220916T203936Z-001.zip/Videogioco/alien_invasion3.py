import sys
import pygame
from settings1 import Settings
from ship1 import Ship

def run_game():
	pygame.init()
	ai_settings = Settings()
	screen = pygame.display.set_mode(
	(ai_settings.screen_width, ai_settings.screen_heigth))
	pygame.display.set_caption("Alien Invasion")
	
#the screen objects is called a surface. a surface is Pygame is a part
#of the screen where you display s game element. each element in the 
#game. like the aliens or the ship, is a surface

	ship = Ship(screen)

	while True:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				sys.exit()
		#redraw the screen elements around
		screen.fill(ai_settings.bg_color)
		ship.blitme()
		#make the most recentrly drawn screen invisible
		pygame.display.flip()
		
#main
run_game()
