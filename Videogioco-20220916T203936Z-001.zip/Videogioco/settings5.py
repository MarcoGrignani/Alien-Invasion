
class Settings():
	"""a class to store all settings for alien invasions"""
	
	def __init__(self):
		"""inizialize the game's static settings"""
		#screen settings
		self.screen_width = 1600 #1600
		self.screen_height = 800 #800
		self.bg_color = (66, 49, 137)#(230, 230, 230)
		
		self.ship_speed_factor = 1.5
		
		self.bullet_speed_factor = 1
		self.bullet_width = 3
		self.bullet_height = 15
		self.bullet_color =  255, 255, 255#60, 60, 60
		self.bullets_allowed = 3
		self.alien_speed_factor = 1
