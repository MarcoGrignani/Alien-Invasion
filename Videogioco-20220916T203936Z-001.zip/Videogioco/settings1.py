
class Settings():
	"""a class to store all settings for alien invasions"""
	
	def __init__(self):
		"""inizialize the game's static settings"""
		#screen settings
		self.screen_width = 1200
		self.screen_heigth = 600
		self.bg_color = (230, 230, 230)
