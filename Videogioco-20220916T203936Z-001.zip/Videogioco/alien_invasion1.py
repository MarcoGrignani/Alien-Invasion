import sys
import pygame

#NB: pygame è package, non classe. Cioè una raccolta di funzioni
#che posso essere invocata senza creare un'istanza

def run_game():
	# Inizialize game and create a screen objects
	pygame.init() #default background settings
	screen = pygame.display.set_mode((1200, 600)) # settings
	pygame.display.set_caption("Alien Invasion")

#the screen objects is called a surface. a surface is Pygame is a part
#of the screen where you display s game element. each element in the 
#game. like the aliens or the ship, is a surface

	#set the background clor
	bg_color = (230, 230, 230)
	
	#start the main loop for the game
	while True:
		#watch for keyboard and mouse events
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				sys.exit()
		#redraw the screen during each pass through the loops
		screen.fill(bg_color)
		#make the most recently  drawn screen visible
		pygame.display.flip()
			
#when we move the game elements around, pygame.display.flip() will
#continually update the dissplay to show the new position of elements
#and hide the old ones, creating the illusion of smooth movement.
	
#main 
run_game()
